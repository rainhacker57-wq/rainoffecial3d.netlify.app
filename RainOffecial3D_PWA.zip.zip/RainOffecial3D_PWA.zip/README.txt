📘 Rain Offecial 3D — PWA → APK Builder Guide

1. Buka https://www.pwabuilder.com
2. Klik “Start” lalu pilih “Upload ZIP”.
3. Pilih file RainOffecial3D_PWA.zip.
4. Klik “Build My App”, pilih Android (TWA).
5. Isi detail:
   • App Name: Rain Offecial 3D
   • Package ID: com.rainoffecial.ai3d
   • Theme Color: #5c00ff
   • Background Color: #000014
6. Klik Build → tunggu → Download Android APK.

Fitur:
- 3D Robot ringan & animasi teks
- Perintah suara (buka YouTube, WhatsApp, dll)
- Offline cache otomatis
- Tema biru–ungu neon

Folder ZIP berisi:
fitur.html
manifest.json
service-worker.js
rainoffecial.jpg
README.txt